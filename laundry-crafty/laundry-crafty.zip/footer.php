</div> <!-- Penutup container -->

    <footer class="text-center py-4 text-muted mt-5">
        <small>&copy; 2025 LaundryCrafty - Sistem Manajemen Laundry</small>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>